import React, { useEffect, useState } from 'react';
import { addBreakTime, addToDb, getBreakTime } from '../../fakeDB/fakeDB';

import Aside from '../Aside/Aside';
import Course from '../Course/Course';
import Header from '../Header/Header';
import Question from '../Question/Question';
import './Main.css'

const Main = () => {
    const [courses, setCourse] = useState([]);
    const [selectedCourse, setSelectedCourse] = useState([])
    const [breakTime, setBreakTime] = useState(0);

    useEffect(() => {
        fetch('data.json')
            .then(res => res.json())
            .then(data => setCourse(data))
    }, [])

    const handleAddTOActivity = (course) => {

        //set the newly selecteditem with a previously selected one.
        const newSelectedCourse = [...selectedCourse, course];
        //sets the value to the state.
        setSelectedCourse(newSelectedCourse);
        addToDb(course.id)
    }

    const breakTimeHandler = (time) => {
        addBreakTime(time)
        const existedBreakTime = getBreakTime();
        setBreakTime(existedBreakTime)
    }

    return (
        <div className='container'>
            <div className="main-section">
                <Header></Header>
                <div className="course-container">
                    {
                        courses.map(course => <Course
                            key={course.id}
                            course={course}
                            handleAddTOActivity={handleAddTOActivity}
                        ></Course>)
                    }
                </div>
                <Question></Question>
            </div>
            <div className="aside-container">
                <Aside
                    key={selectedCourse.id}
                    selectedCourse={selectedCourse}
                    breakTimeHandler={breakTimeHandler}
                    breakTime={breakTime}
                ></Aside>
            </div>
        </div>
    );
};

export default Main;