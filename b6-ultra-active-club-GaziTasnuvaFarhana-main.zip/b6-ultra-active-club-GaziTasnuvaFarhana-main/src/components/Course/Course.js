import React from 'react';
import './Course.css'

const Course = ({ course, handleAddTOActivity }) => {

    const { name, picture, time, } = course;
    return (
        <div className='course-card'>
            <img src={picture} alt={name} />
            <div className="course-info">
                <h2>{name}</h2>
                <p>Duration: <strong>{time}</strong> hours</p>
            </div>
            <button className='add-list-btn' onClick={() => handleAddTOActivity(course)}>
                <h3>Add to learn</h3>
            </button>
        </div>
    );
};

export default Course;