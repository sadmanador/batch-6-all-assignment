import React from 'react';
import './Header.css'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faBookOpen } from '@fortawesome/free-solid-svg-icons'

const Header = () => {
    return (
        <div>
            <header className='heading'>
                <FontAwesomeIcon icon={faBookOpen} className='icon'></FontAwesomeIcon>
                <h2>Brain_Beans</h2>
            </header>
            <h3>Take Courses as many as you want</h3>
        </div>
    );
};

export default Header;