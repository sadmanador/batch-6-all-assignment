import React from 'react';
import './Question.css'

const Question = () => {
    return (
        <div className='question__container'>
            <div>
                <h3>React</h3>
                <p>React is a component based js library that allows the developer to make SPA. react uses a virtual-DOM unlike JS DOM that renders JSX code to make HTML like elements. Router of react helps to lazyLoad data behind the scene and gives a flawless, reloading experience for users.</p>
            </div>
            <div>
                <h3>Props vs State</h3>
                <p>
                    <ul>
                        <li>props are properties to pass data component to component</li>
                        <li>state on the other hand is a hook, that helps to change the state(DOM manipulation in JS, or sometime event-listening) to render any thing that is changeable.</li>
                    </ul>
                </p>
            </div>
            <div>
                <h3>useEffect uses (except fetch or async)</h3>
                <p>
                    <ul>
                        <li>useEffect should be use any case where things doesn't rely on code. like loading anything from sessionStorage or localStorage.</li>
                        <li>Can be used where sets of code should reply on other statement to be completed, cause useEffect takes dependencies.</li>
                        <li>Other asynchronous functions like setTimeOut or setInterval are used in useEffect.</li>
                    </ul>
                </p>
            </div>
        </div>
    );
};

export default Question;