import React from 'react';
import TimeRadio from '../TimeRadio/TimeRadio';
import User from '../User/User';
import './Aside.css'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Aside = ({ selectedCourse, breakTimeHandler, breakTime }) => {
    
    let total = 0;
    for (let course of selectedCourse) {
        total = total + course.time;
    }

    const notify = () => toast(`Congratulations!!! You have completed`);
    return (
        <div className='aside'>
            <User></User>

            <TimeRadio
                breakTimeHandler={breakTimeHandler}
                breakTime={breakTime}
            ></TimeRadio>

            <h2>Course Schedule Details</h2>
            <div className="course-time__container">
                <h3>Course Time: {total} hours</h3>
            </div>
            <div className='breakTime__container'>
                <h3>Break Time: {breakTime} hours</h3>
            </div>
            <button className='btn-complete' onClick={notify}>Course Completed</button>
            <ToastContainer></ToastContainer>
        </div>
    );
};

export default Aside;