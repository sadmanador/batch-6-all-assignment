import React from 'react';
import './TimeRadio.css'

const TimeRadio = (props) => {
    const { breakTime, breakTimeHandler } = props
    return (
        <div>
            <h3>Add A Break</h3>
            <div className="radio__container">
                <input type="radio" className="radio__input" id="myRadio1" name='myRadio' value={10} onClick={event => breakTimeHandler(event.target.value)}/>
                <label htmlFor="myRadio1" className="radio__label">10 hrs</label>
                <input type="radio" className="radio__input" id="myRadio2" name='myRadio' value={20} onClick={event => breakTimeHandler(event.target.value)}/>
                <label htmlFor="myRadio2" className="radio__label">20 hrs</label>
                <input type="radio" className="radio__input" id="myRadio3" name='myRadio' value={30} onClick={event => breakTimeHandler(event.target.value)}/>
                <label htmlFor="myRadio3" className="radio__label">30 hrs</label>
                <input type="radio" className="radio__input" id="myRadio4" name='myRadio' value={40} onClick={event => breakTimeHandler(event.target.value)}/>
                <label htmlFor="myRadio4" className="radio__label">40 hrs</label>
                <input type="radio" className="radio__input" id="myRadio5" name='myRadio' value={50} onClick={event => breakTimeHandler(event.target.value)}/>
                <label htmlFor="myRadio5" className="radio__label">50 hrs</label>
            </div>
        </div>
    );
};

export default TimeRadio;