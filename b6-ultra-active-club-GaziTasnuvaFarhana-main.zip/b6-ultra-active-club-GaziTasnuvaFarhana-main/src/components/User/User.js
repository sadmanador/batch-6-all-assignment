import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faLocationDot } from '@fortawesome/free-solid-svg-icons'
import './User.css'


const User = () => {
    return (
        <div>
            <div className='user'>
                <img className='user-img' src="/user-avatar.jpg" alt="" />
                <div className="user-info">
                    <p className='user__name'>Gazi Tasnuva Esha</p>
                    <div className="user-location">
                        <FontAwesomeIcon icon={faLocationDot}></FontAwesomeIcon>
                        <p>Dhaka, Bangladesh</p>
                    </div>
                </div>
            </div>
            <div className="user__properties">
                <div className="weight">
                    <p className='text-value'>55<small className='faded-text'>kg</small></p>
                    <p className="text-details">Weight</p>
                </div>
                <div className="height">
                    <p className='text-value'>5.7</p>
                    <p className="text-details">Height</p>
                </div>
                <div className="age">
                    <p className='text-value'>27<small className="faded-text">yrs</small></p>
                    <p className="text-details">Age</p>
                </div>
            </div>
        </div>
    );
};

export default User;