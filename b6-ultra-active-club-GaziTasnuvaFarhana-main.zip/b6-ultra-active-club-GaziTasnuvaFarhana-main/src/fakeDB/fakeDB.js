const addToDb = id => {
    let shoppingCart = {};


    const storedCart = localStorage.getItem('course-dashBoard');
    if (storedCart) {
        shoppingCart = JSON.parse(storedCart);
    }


    const quantity = shoppingCart[id];
    if (quantity) {
        const newQuantity = quantity + 1;
        shoppingCart[id] = newQuantity;
    }
    else {
        shoppingCart[id] = 1;
    }
    localStorage.setItem('course-dashBoard', JSON.stringify(shoppingCart));
}


const addBreakTime = (time) => {
    localStorage.setItem('breakTime', time)
}

const getBreakTime = () => {
    const storedBreakTime = localStorage.getItem('breakTime');
    if(storedBreakTime){
        return storedBreakTime;
    }
}

export { addToDb, getBreakTime, addBreakTime }