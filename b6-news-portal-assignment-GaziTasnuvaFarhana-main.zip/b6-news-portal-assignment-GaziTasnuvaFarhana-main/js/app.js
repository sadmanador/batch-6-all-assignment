const loadData = () => {
    const url = 'https://openapi.programming-hero.com/api/news/categories';
    fetch(url)
        .then(response => response.json())
        .then(data => displayCategoryOfNews(data.data.news_category))
        .catch(error => console.log(error))
};

const displayCategoryOfNews = categories => {
    const categoryListContainer = document.getElementById('category-list')

    categories.forEach(category => {
        const categoryDiv = document.createElement('div');
        categoryDiv.classList.add('individual-category');
        categoryDiv.innerHTML = `
        <p id="spinner" onclick="loadingNewsCards('${category.category_id}')">${category.category_name}</p>
        `;
        categoryListContainer.appendChild(categoryDiv);
    });
};

const loadingNewsCards = async (news) => {
    toggleSpinner(true)
    const url = `https://openapi.programming-hero.com/api/news/category/${news}`

    try {
        const res = await fetch(url);
        const data = await res.json();
        displayCard(data.data)
    }
    catch (error) {
        console.log(error)
    }


};

const displayCard = cards => {
    

    //getting the card container
    const cardContainer = document.getElementById('card-container');
    cardContainer.innerHTML = '';


    const newsNum = document.getElementById('foundNews');
    const newsFeed = cards.length
    newsNum.innerText = newsFeed;

    const noNewsFeed = document.getElementById('noNewsFeed');
    if (newsFeed === 0) {
        noNewsFeed.classList.remove('d-none');
    }
    else {
        noNewsFeed.classList.add('d-none');
    }


    cards.forEach(card => {
        const viewCard = document.createElement('div')
        viewCard.classList.add('col')
        viewCard.innerHTML = `
        <div class="card h-100 shadow rounded-4">
                        <img src="${card.thumbnail_url}" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">${card.title}</h5>
                            <p class="card-text">${card.details}</p>
                            <div class="card-footer">
                                <div class="author">
                                    <img src="${card.author.img}" class="author-img">
                                    <div class="author-detail">
                                        <p class="author-name">${card.author.name ? card.author.name : "No author name found"}</p>
                                        <p class="release-date">${card.author.published_date ? card.author.published_date : "No date found"}</p>
                                    </div>
                                </div>
                                <div class="view">
                                    <i class="fa-sharp fa-solid fa-eye"></i><span class="view-number"> ${card.total_view ? card.total_view : "Unavailable"}</span>
                                </div>
                                <div class="modal-section">
                                    <button data-bs-toggle="modal" data-bs-target="#fullNewsModal" class="btn btn-outline-primary"  onclick="loadDetailNews('${card._id}')"><i class="fa-solid fa-arrow-right"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
        `;
        cardContainer.appendChild(viewCard)
    })
    toggleSpinner(false)
};

const loadDetailNews = detail => {
    const url = `https://openapi.programming-hero.com/api/news/${detail}`

    fetch(url)
        .then(res => res.json())
        .then(data => displayModal(data.data[0]))
        .catch(error => console.log(error))
}

const displayModal = detail => {
    console.log(detail)
    const modalContainer = document.getElementById('modal-box')
    modalContainer.innerHTML = '';

    const modalContent = document.createElement('div');
    modalContent.classList.add('modal-content');
    modalContent.innerHTML = `
    <div class="modal-header">
    <h1 class="modal-title fs-5 text-center" id="exampleModalLabel">${detail.title}</h1>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
    </div>
    <div class="modal-body">
        <img src="${detail.image_url}" class="modal-img w-100">
        <p class="modal-para">${detail.details}</p>
    </div>
    <div class="author-data d-flex justify-content-evenly">
        <img src="${detail.author.img}" class="author-img mb-2">
        <p class="modal-author">${detail.author.name ? detail.author.name : "No author found"}</p>
        <p class="modal-date">${detail.author.published_date ? detail.author.published_date : "No author found"}</p>
        <p class="modal-view"><i class="fa-sharp fa-solid fa-eye"></i>${detail.total_view ? detail.total_view : "No data available"}</p>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
    </div>
    `;
    modalContainer.appendChild(modalContent);
};



const toggleSpinner = isLoading => {
    const loaderId = document.getElementById('spinner-icon');
    if (isLoading) {
        loaderId.classList.remove('d-none')
    }
    else {
        loaderId.classList.add('d-none')
    }
}












loadingNewsCards('01')
loadData();