const playerSelectionBtn = document.querySelectorAll('.btn');
for (let selectedPlayer of playerSelectionBtn){
    selectedPlayer.addEventListener('click', function(event){
        const selectedBtn = event.target;
        selectedBtn.setAttribute('disabled', true);

        const playerName = event.target.previousElementSibling.innerText;
        
        const playerList = document.getElementById('playerList')

        const li = document.createElement('li');
        li.innerText = playerName;
        li.classList.add('selected-players');

        const selectedPlayer = document.getElementsByClassName('selected-players')
        const numberOfPlayer = selectedPlayer.length;

        if (numberOfPlayer < 5) {
            playerList.appendChild(li);
        }
        else {
            alert("Maximum 5 Players only!")
            return;
        }
    })
}


//removes selected players from the list
document.getElementById('playerList').addEventListener('click', (event) => {
    event.target.parentNode.removeChild(event.target);
});


document.getElementById('calculate').addEventListener('click', function () {
    const perPlayer = document.getElementById('per-player');
    const perPlayerString = perPlayer.value;
    const perPlayerInt = parseFloat(perPlayerString);

    //selecting selected player
    const selectedPlayer = document.getElementsByClassName('selected-players')
    const numberOfPlayer = selectedPlayer.length;

    if (isNaN(perPlayerString)) {
        alert("Please insert Number only!")
    }
    else {
        const playerExpanse = perPlayerInt * numberOfPlayer;
        setTextValueByID('total-player', playerExpanse)
    }
});

document.getElementById('calculate-total').addEventListener('click', function () {
    const managerFee = document.getElementById('manager-fee');
    const managerFeeString = managerFee.value;
    const managerFeeInt = parseFloat(managerFeeString);

    const coachFee = document.getElementById('coach-fee');
    const coachFeeString = coachFee.value;
    const coachFeeInt = parseFloat(coachFeeString);

    if (isNaN(managerFeeString) || isNaN(coachFeeString)) {
        alert("Please insert Number only!")
    }
    else {
        const totalPlayerExpanse = document.getElementById('total-player');
        const totalPlayerExpanseString = totalPlayerExpanse.innerText;
        const totalPlayerExpanseInt = parseFloat(totalPlayerExpanseString);

        const grandTotal = managerFeeInt + coachFeeInt + totalPlayerExpanseInt;
        setTextValueByID('grand-total', grandTotal)
    }
});