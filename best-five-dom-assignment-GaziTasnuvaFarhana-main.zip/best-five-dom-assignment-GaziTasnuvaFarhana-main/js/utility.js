function setTextValueByID(id, value){
    const textElement = document.getElementById(id)
    textElement.innerText = value;
}