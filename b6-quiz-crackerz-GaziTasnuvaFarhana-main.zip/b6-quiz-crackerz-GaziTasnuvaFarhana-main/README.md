# This project is to create a quiz based app

Quiz mania offers easy to participate quizzes to check you knowledge on certain programming field.

## Technologies

1. React-Bootstrap
2. FontAwesome
3. React-Router
4. Toastify
5. Active routes

